package org.cipher.ciphtypes.transposition;

import org.cipher.interfaces.CipherInterface;
import org.cipher.interfaces.Printable;
import org.cipher.utils.AsciiGenerator;

import java.util.Arrays;

/**
 * <b>Transposition cipher</b>
 *
 * In cryptography, a transposition cipher is a method of encryption by which the positions
 * held by units of plaintext (which are commonly characters or groups of characters) are
 * shifted according to a regular system, so that the ciphertext constitutes a permutation of
 * the plaintext. That is, the order of the units is changed (the plaintext is reordered).
 * Mathematically a bijective function is used on the characters' positions to encrypt and an
 * inverse function to decrypt.
 *
 * FOR MORE INFO LOOK AT <a href="https://en.wikipedia.org/wiki/Transposition_cipher"> LINK</a>
 * ALSO YOU CAN CHECK THIS <a href="http://practicalcryptography.com/ciphers/classical-era/"> ANOTHER LINK</a>
 *
 * @author Piotr 'pitrecki' Nowak
 * @version 0.0.1
 * Created by Pitrecki on 2016-10-27.
 * @see org.cipher.interfaces.CipherInterface
 * @see org.cipher.interfaces.Printable
 */
public abstract class TranspositionCipher implements CipherInterface, Printable
{
    private String text;
    private char[][] cryptMatrix;

    public TranspositionCipher() {
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public char[][] getCryptMatrix() {
        return cryptMatrix;
    }

    public void setCryptMatrix(char[][] cryptMatrix) {
        this.cryptMatrix = cryptMatrix;
        for (int i = 0; i < cryptMatrix.length; i++)
            Arrays.fill(this.cryptMatrix[i], '*');
    }

    public void setValueInCryptMatrix(int row, int column, char letter) {
        this.cryptMatrix[row][column] = letter;
    }

    protected abstract void cryptArrayGenerator(String strText);

    @Override
    public abstract void decrypt(String inputText);

    @Override
    public abstract void encrypt(String inputText);

    @Override
    public String prepareDataToPrint() {
        return  getText();
    }
}
