package org.cipher.ciphtypes.transposition;

import java.util.Arrays;

/**
 * Created by Pitrecki on 2016-10-28.
 */
public class RailFenceCipher extends TranspositionCipher
{
    private final int RAIL_KEY;

    public RailFenceCipher(int key) {
        super();
        this.RAIL_KEY = key;
    }

    @Override
    protected void cryptArrayGenerator(String strText) {
        String temp = strText.replaceAll(" ", "");
        setCryptMatrix(new char[RAIL_KEY][temp.length()]);

        char[] textToCharArray = temp.toCharArray();

        int textCharIndex = 0;
        try {
            for (int j = 0; j < getCryptMatrix()[0].length; j += RAIL_KEY + 1) {
                int row = 0;
                int column = j;
                do {
                    char letter = textToCharArray[textCharIndex];
                    setValueInCryptMatrix(row, column, letter);
                    row++;
                    column++;
                    textCharIndex++;
                } while (row < getCryptMatrix().length);

                row -= 1;
                column -= 1;

                do {
                    row--;
                    column++;
                    char letter = textToCharArray[textCharIndex];
                    setValueInCryptMatrix(row, column, letter);
                    textCharIndex++;
                } while (row > 1);
            }
        } catch (ArrayIndexOutOfBoundsException e) {}

    }

    @Override
    public void encrypt(String inputText) {
        cryptArrayGenerator(inputText);
        char[][] tmpCryptMatrix = getCryptMatrix();
        StringBuffer buffer = new StringBuffer();

        for (int i = 0; i < tmpCryptMatrix.length; i++)
            buffer.append(Arrays.toString(tmpCryptMatrix[i]));

        String tmp = buffer.toString().replace("]", "").replace("[", "").replace(",", "").replace("*", "").replace(" ", "");

        setText(tmp);

    }

    @Override
    public void decrypt(String inputText) {
//        cryptArrayGenerator(inputText);
//        char[][] tmp = getCryptMatrix();
//        for (int i = 0; i < tmp.length; i++)
//            System.out.println(Arrays.toString(tmp[i]));

        /**
         * SOLUTIOON
         *
         */

    }
}
